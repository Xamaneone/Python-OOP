import unittest

class TestMagicCard(unittest.TestCase):
    pass


if __name__ == '__main__':
    unittest.main()