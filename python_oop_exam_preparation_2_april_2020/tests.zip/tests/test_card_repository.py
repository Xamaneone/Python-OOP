import unittest

class TestCardRepository(unittest.TestCase):
    pass


if __name__ == '__main__':
    unittest.main()