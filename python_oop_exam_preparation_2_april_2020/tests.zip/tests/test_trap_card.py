import unittest

class TestTrapCard(unittest.TestCase):
    pass


if __name__ == '__main__':
    unittest.main()